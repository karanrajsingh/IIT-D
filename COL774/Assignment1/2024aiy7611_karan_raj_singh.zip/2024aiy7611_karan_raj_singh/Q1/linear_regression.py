# Imports - you can add any other permitted libraries
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from mpl_toolkits.mplot3d import Axes3D
import time
import itertools

# You may add any other functions to make your code more modular. However,
# do not change the function signatures (name and arguments) of the given functions,
# as these functions will be called by the autograder.

class LinearRegressor:

    theta = 0

    def __init__(self):        
        "Initializing Linear Regressor model"
        '''
        Instructions:
        1. Toggle between the two thresholds
        2. For learning rate = 0.001 use 1e-11 as threshold
        '''
        self.threshold = 1e-11
        #self.threshold = 1e-12

    def error(self, y1, y2):
        return np.square(np.linalg.norm(y1 - y2))/(y1.shape)
        
    
    def splitTrainTest(self, X, y):
        X_train, y_train = X[ : 80], y[ : 80]
        X_test, y_test = X[80 : ], y[80 : ]
        return X_train, y_train, X_test, y_test

    def readData(self, path_X, path_Y):
        X = np.loadtxt(path_X)
        y = np.loadtxt(path_Y)
        return X, y 

    '''
    Returns the Loss function value at a given parameter
    '''
    def checkLoss(self, X, y, Theta):
        Hyp = np.matmul(X, Theta)
        L = y - Hyp
        loss = np.dot(L, L)/(2*X.shape[0])
        loss = np.square(np.linalg.norm(L))/(2*X.shape[0])
        return loss
        
    def fit(self, X, y, learning_rate=0.01):
        """
        Fit the linear regression model to the data using Gradient Descent.
        
        Parameters
        ----------
        X : numpy array of shape (n_samples, n_features)
            The input data.
            
        y : numpy array of shape (n_samples,)
            The target values.

        learning_rate : float
            The learning rate to use in the update rule.
            
        Returns
        -------
        List of Parameters: numpy array of shape (n_iter, n_features+1,)
            The list of parameters obtained after each iteration of Gradient Descent.
        """

        #Adding bias term
        Ones = np.ones([X.shape[0],1])
        X = np.concatenate((Ones, X.reshape(X.shape[0], 1)), axis=1)

        #Starting parameters
        Theta = np.zeros(X.shape[1])
        norm = 1e+12
        epochs = 0
        t = np.array(Theta.reshape(1, X.shape[1]))

        t0 = time.time()
        # Batch Gradient Descent Algorithm
        while(norm > self.threshold):
            #print(epochs, norm, Theta)
            epochs += 1
            A = np.dot(X, Theta)
            B = y - A
            Grad = -1*np.matmul(X.T, B)/X.shape[0]
            Theta = Theta - learning_rate*Grad
            norm = np.linalg.norm(Grad)
            tt = Theta.reshape(1, Theta.shape[0])
            t = np.append(t, tt, axis = 0)
        t1 = time.time()
        print('Converges in {} seconds for '.format(t1 - t0) + '{} epochs.'.format(epochs))
        global theta
        theta = t
        return theta

    def predict(self, X):
        """
        Predict the target values for the input data.
        
        Parameters
        ----------
        X : numpy array of shape (n_samples, n_features)
            The input data.
            
        Returns
        -------
        y_pred : numpy array of shape (n_samples,)
            The predicted target values.
        """
        #Adding bias term
        Ones = np.ones([X.shape[0],1])
        X = np.concatenate((Ones, X.reshape(X.shape[0], 1)), axis=1)
        p = theta[len(theta) - 1]
        y_p =  np.matmul(X, p)
        return y_p
    
    def plot(self, X, y):
        #Plotting Linear Regression Hypothesis fit
        fig = plt.figure(figsize=(15, 9), facecolor='white')
        axes = plt.axes()
        plt.title('Linear Regression to predict wine density based on acidity')
        plt.scatter(X, y,s = 0.75,label = 'Training Data', c = 'blue')
        plt.xlabel('Wine Acidity')
        plt.ylabel('Wine Density')
        Ones = np.ones([X.shape[0],1])
        X = np.concatenate((Ones, X.reshape(X.shape[0], 1)), axis=1)
        param = theta[len(theta) - 1]
        predicted = np.matmul(X, param)
        plt.plot(X[:,1], predicted, linewidth = 1.5, label = 'Learned Hypothesis', c = 'red')
        plt.legend(loc = "lower right")
        plt.show()

        #Plotting Loss function
        d1 = np.linspace(-25, 50, num=300, endpoint=False)
        d2 = np.linspace(-10, 50, num=300, endpoint=False)
        v1, v2 = np.meshgrid(d1, d2)
        t  = np.stack([v1, v2], axis = -1)
        loss = np.apply_along_axis(lambda th : self.checkLoss(X, y, th), 2, t)
        fig = plt.figure()        
        axes2 = fig.add_subplot(title='Loss function', projection='3d', xlabel='theta0', ylabel='theta1', zlabel='  Loss')
        axes2.set_zlim3d(np.min(loss), np.max(loss))
        surface = axes2.plot_surface(v1, v2, loss, label='Loss Function', cmap = cm.gist_rainbow)        
        plt.show()

        #Plotting movement of parameters
        fig = plt.figure()
        axes3 = fig.add_subplot(title = 'Movement of parameters with epochs', projection = '3d', xlabel='theta0', ylabel='theta1', zlabel='  Loss')
        axes3.set_zlim3d(np.min(loss), 2*np.max(loss))
        surface = axes3.plot_surface(v1, v2, loss, label = 'Loss function', alpha = 0.25, cmap = cm.gist_rainbow)
        th_str = theta[0]
        l_str = self.checkLoss(X, y, th_str)
        for i in range(len(theta) - 1):
            th_end = theta[i+1]
            l_end = self.checkLoss(X, y, th_end)
            u = th_end[0] - th_str[0]
            v = th_end[1] - th_str[1]
            w = l_end - l_str
            th_str, l_str = th_end, l_end
            axes3.quiver(th_str[0], th_str[1], l_str, u, v, w, colors = 'blue')       
        plt.show()

        #Plotting contours
        fig = plt.figure()
        axes4 = fig.add_subplot(title = 'Contour plot',  xlabel = 'theta0', ylabel = 'theta1')
        axes4.contour(v1, v2, loss, 100)   
        axes4.scatter(theta[:, 0], theta[:, 1])
        plt.show()
